import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Pais {
    String nome;
    double consumoVinho;

    public Pais(String nome, double consumoVinho) {
        this.nome = nome;
        this.consumoVinho = consumoVinho;
    }
}

public class Bebidas {
    public static void main(String[] args) {
        List<Pais> paises = new ArrayList<>();

        InputStream inputStream = Bebidas.class.getResourceAsStream("drinks.csv");
        try (BufferedReader leitor = new BufferedReader(new InputStreamReader(inputStream))) {
            String linha;
            while ((linha = leitor.readLine()) != null) {
                String[] tokens = linha.split(",");
                if (tokens.length >= 4) {
                    String nomePais = tokens[0];
                    String consumoString = tokens[3];
                    double consumoVinho = 0.0;
                    try {
                        consumoVinho = Double.parseDouble(consumoString);
                    } catch (NumberFormatException e) {
                        continue;
                    }
                    paises.add(new Pais(nomePais, consumoVinho));
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao ler os dados do arquivo: " + e.getMessage());
            return;
        }

        Collections.sort(paises, Comparator.comparingDouble(p -> p.consumoVinho));

        // Imprimir a lista ordenada
        System.out.println("Países ordenados pelo consumo de vinho em 2010:");
        for (Pais pais : paises) {
            System.out.println("País que mais consome vinho: " + pais.nome + "\nQuantidade: " + pais.consumoVinho);
            System.out.println();
        }
    }
}
